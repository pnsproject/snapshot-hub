import { strategies } from '../../helpers/strategies';

export default function() {
  return strategies;
}
